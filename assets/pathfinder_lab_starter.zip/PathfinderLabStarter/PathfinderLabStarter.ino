#include <Romi32U4.h>
#include "FWR_Servo.h"

Romi32U4Motors motors;
Romi32U4ButtonA buttonA;
Romi32U4LCD lcd;
FWR_Servo myservo;

#define SERVO_PIN       20
#define TRIGGER_PIN     21
#define ECHO_PIN        22

#define CELL_LENGTH_CM  10
#define DEPTH           8 
#define WIDTH           12

unsigned int grid[DEPTH][WIDTH]; // 0 = free, 1 = occupied

void setup()
{
  unsigned int counter;
  uint16_t batteryLevel;

  // Intialize sonar pins
  pinMode(TRIGGER_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  // Attach servo
  myservo.attach(SERVO_PIN);

  // Begin serial
  Serial.begin(9600);

  // Loop the code within { } until A is pressed
  while (!buttonA.isPressed()) {
    // read the battery level and store it in a variable
    batteryLevel = readBatteryMillivolts();
    
    lcd.clear();  // clear the LCD
    lcd.print("B=");
    lcd.print(batteryLevel); // print the battery voltage 
    lcd.print("mV");
    lcd.gotoXY(0, 1);
    lcd.print("Press A");

    delay(100); // Pause for 100ms
  }
  lcd.clear();

  // Always wait for the button to be released so that Romi doesn't
  // start moving until your hand is away from it.
  delay(1000);
  motors.setSpeeds(0, 0);
}

// Helper function for measuring distance
int getDistance() {
  digitalWrite(TRIGGER_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIGGER_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIGGER_PIN, LOW);
  long duration = pulseIn(ECHO_PIN, HIGH);
  return (duration/2) / 29.1;
}

void loop()
{
  // Sweep from 0 to 180 degrees and take distance measurements
  for (int deg = 0; deg <= 180; deg += 10) {
    myservo.write(deg);
    int angle = 90 - deg;
    Serial.println(angle);
    lcd.clear();
    lcd.print("Ang=");
    lcd.print(angle); // Print the angle
    delay(250); // Give the servo time to reach the angle
    
    /** 
     *  TODO: use getDistance() to get the distance measurement. We recommend 
     *  sampling multiple times per angle, throwing out obvious outliers, and 
     *  taking an average
     */
     int distance = 0;

    /** 
     *  TODO: convert your (angle, distance) pair to cartesian coordinates 
     *  (x, y). Hint: remember that x = r*cos(angle), y = r*sin(angle)
     */
     int x = 0;
     int y = 0;

    /** 
     *  TODO: mark the correct grid as 
     *  (x, y). Hint: remember that x = r*cos(angle), y = r*sin(angle)
     */

    lcd.gotoXY(0, 1);
    lcd.print("Dist=");
    lcd.print(getDistance()); // Print the distance
    delay(250);
  }

  /** 
    *  TODO: drive in the direction with the fewest obstacles (left or right) 
    *  Hint: compare the number of occupied cells for each side
    */

    exit(0);
}

